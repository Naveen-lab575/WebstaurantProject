package Project1.Project;


import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;


@SuppressWarnings("unused")
public class AppTest 
{
	
	static WebDriver driver;
	
	
	public static void main( String[] args ) throws InterruptedException, IOException {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naveen\\Downloads\\chromedriver_win32\\chromedriver.exe");
	driver = new ChromeDriver();
	
	driver.get("https://www.webstaurantstore.com/");
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	driver.findElement(By.xpath("//input[@id='searchval']")).click();
	
	driver.findElement(By.xpath("//input[@id='searchval']")).sendKeys("stainless work table");
	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	driver.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	
String tablewithundershelf = driver.findElement(By.xpath("//a[contains(text(),'Stainless Steel Work Tables with Undershelf')]")).getText();
	
	System.out.println(tablewithundershelf);
	
	if((tablewithundershelf).contains("Tables"))
	{
		System.out.println("Found the First word");
	}
	
String openbasework = driver.findElement(By.xpath("//a[contains(text(),'Stainless Steel Open Base Work Tables')]")).getText();
	
	System.out.println(openbasework);
	
	if((openbasework).contains("Tables"))
	{
		System.out.println("Found the Second word");
	}
	
	
String enclosedcommercialwork = driver.findElement(By.xpath("//a[contains(text(),'Stainless Steel Enclosed Base Commercial Work Tables')]")).getText();
	
	System.out.println(enclosedcommercialwork);
	
	if((enclosedcommercialwork).contains("Tables"))
	{
		System.out.println("Found the Third word");
	}
	
String presenstationstation = driver.findElement(By.xpath("//a[contains(text(),'Work Table Preparation Stations')]")).getText();
	
	System.out.println(presenstationstation);
	
	if((presenstationstation).contains("Table"))
	{
		System.out.println("Found the Fourth word");
	}
	
	
String foldingwork = driver.findElement(By.xpath("//a[contains(text(),'Stainless Steel Folding Work Tables')]")).getText();
	
	System.out.println(foldingwork);
	
	if((foldingwork).contains("Tables"))
	{
		System.out.println("Found the Fifth word");
	}
	
String wallmount = driver.findElement(By.xpath("//a[contains(text(),'Stainless Steel Wall Mount Work Tables')]")).getText();
	
	System.out.println(wallmount);
	
	if((wallmount).contains("Tables"))
	{
		System.out.println("Found the sixth word");
	}
	
String equipmentstand= driver.findElement(By.xpath("//a[contains(text(),'Work Table and Equipment Stand')]")).getText();
	
	System.out.println(equipmentstand);
	
	if((equipmentstand).contains("Table"))
	{
		System.out.println("Found the seventh word");
	}
	
	
String portable= driver.findElement(By.xpath("//a[contains(text(),'Portable Work Tables')]")).getText();
	
	System.out.println(portable);
	
	if((portable).contains("Table"))
	{
		System.out.println("Found the eight word");
	}
	
 driver.findElement(By.xpath("//a[contains(text(),'Portable Work Tables')]")).click();
	

	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	

	 WebDriverWait wait = new WebDriverWait(driver,30);
	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='addToCartButton']")));
	 
	 driver.findElement(By.xpath("//input[@name='addToCartButton']")).click();

	 driver.findElement(By.xpath("//a[contains(text(),'View Cart')]")).click();
     
	 WebDriverWait wait1 = new WebDriverWait(driver,30);
	 wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Empty Cart')]")));
	 
	 driver.findElement(By.xpath("//a[contains(text(),'Empty Cart')]")).click();
	
	 WebDriverWait wait2 = new WebDriverWait(driver,30);
	 wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Empty Cart')]")));
	 
driver.findElement(By.xpath("//button[contains(text(),'Empty Cart')]")).click();

Thread.sleep(10000);

takeScreenshot("emptyCart");

	}




public static void takeScreenshot(String fileName) throws IOException{
	// Take screenshot and store as a file format
	File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	// now copy the screenshot to desired location using copyFile //method
	FileUtils.copyFile(src, 
			new File("C:\\Users\\Naveen\\eclipse-workspace\\Project\\src\\test\\java\\Project" + fileName +".png"));


}

}

